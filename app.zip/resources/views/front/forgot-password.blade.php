<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Artimar Forgot Password</title>
    <meta name="robots" content="noindex, nofollow" />
    <link rel="shortcut icon" href="{{ asset('assets/front/img/fivicon.png')}}" type="image/x-icon" />

    <!-- Fonts & Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet" />

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('assets/front/css/style.css')}}" />
    <link rel="stylesheet" href="{{ asset('assets/front/css/login.css')}}" />
    <style>
    body {
        position: relative;
        margin: 0;
        padding: 0;
        font-family: 'Ubuntu', sans-serif;
        background: url('{{ asset('assets/front/img/backgroud.png')}}') no-repeat center center fixed;
        background-size: cover;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }    
    </style>
</head>

<body>
    <div class="login-container">
        <div class="logo">
            <a href="{{ url('/') }}">
                <img src="{{ asset('assets/front/img/logo.png') }}" alt="Artimar Logo" />
            </a>
        </div>
        <h3>Forgot Password?</h3>
        <p>No Worries, We'll Send You Reset Instructions.</p>
        @if(session('status'))
        <div class="alert alert-success">{{ session('status') }}</div>
        @endif

        @if($errors->any())
        <div class="alert alert-danger">
            {!! implode('<br>', $errors->all()) !!}
        </div>
        <pre>{{ print_r(session()->all(), true) }}</pre>
        @endif
        <form method="POST" action="{{ route('forgot.password.email') }}">
            @csrf
            <div class="form-group text-start mb-3">
                <label for="email">Email ID </label><span style="color:red;">*</span>
                <input type="email" id="email" name="email" class="form-control" placeholder="e.g. john@artimar.com"
                    required />
            </div>
            <div class="text-center my-5 d-flex align-items-center justify-content-center gap-4">
                <!-- <button class="btn btn-dark btn-primary px-4">Next Step</button> -->

                <button type="submit" class="btn btn-dark btn-primary px-4">Reset Password</button>
            </div>
        </form>
        <a href="{{ route('login') }}" class="back-link"> <- Back To Log In</a>
    </div>
</body>

</html>