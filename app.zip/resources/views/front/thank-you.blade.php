@extends('front.layouts.app')
@section('content')

<style>
    .section-cl.top-step-section .row {
        display: none;
    }
</style>
    <!-- Steps Section -->
    <div class="main-pg">
        <section class="thank-you-section">
            <div class="container">
                <div class="thank-you-text">                    
                    <img src="{{ asset('assets/front/img/thank-you@2x.png')}}" alt="img">
                </div>
                <div class="info-text">
                    <p>We've Received Your Quote Request. You'll Receive A Free, Personalized Quote As Soon As Possible.
                    </p>
                    <button class="btn btn-dark btn-primary">Go Back to home</button>
                </div>
            </div>
        </section>
    </div>
    </div>
    </div>
    </div>
    </div>

    @endsection