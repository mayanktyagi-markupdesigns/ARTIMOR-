<footer class="app-footer">
    <!--begin::To the end-->
    <div class="float-end d-none d-sm-inline">Anything you want</div>
    <!--end::To the end-->
    <!--begin::Copyright-->
    <strong>
        © 2025, made with ❤️ by&nbsp;
        <a href="https://www.markupdesigns.com/" class="text-decoration-none" target="_blank">Markup Design</a>.
    </strong>
    All rights reserved.
    <!--end::Copyright-->
</footer>