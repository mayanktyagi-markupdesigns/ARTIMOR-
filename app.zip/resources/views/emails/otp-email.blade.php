<p>Hello,</p>

<p>You are receiving this email because we received a password reset request for your account.</p>

<p>Your One-Time Password (OTP) for password reset is: <strong>{{ $otp }}</strong></p>

<p>This OTP will expire in 10 minutes.</p>

<p>If you did not request a password reset, please ignore this email.</p>
