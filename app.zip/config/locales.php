<?php

return [
    'supported' => [
        'en' => [
            'label' => 'English (GB)',
            'short' => 'EN',
        ],
        'de' => [
            'label' => 'Deutsch (DE)',
            'short' => 'DE',
        ],
        'fr' => [
            'label' => 'Français (FR)',
            'short' => 'FR',
        ],
        'nl' => [
            'label' => 'Nederlands (BE)',
            'short' => 'NL',
        ],
    ],
];

