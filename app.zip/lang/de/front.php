<?php

return [
    'home' => 'Startseite',
    'contact_us' => 'Kontakt',
    'visit_us_daily' => 'Besuchen Sie uns täglich:',
    'connect_with_us' => 'Kontaktieren Sie uns:',
    'dropdown_language_label' => 'Sprache',
];

