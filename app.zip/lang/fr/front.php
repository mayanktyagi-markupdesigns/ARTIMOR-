<?php

return [
    'home' => 'Accueil',
    'contact_us' => 'Contactez-nous',
    'visit_us_daily' => 'Visitez-nous chaque jour :',
    'connect_with_us' => 'Contactez-nous :',
    'dropdown_language_label' => 'Langue',
];

