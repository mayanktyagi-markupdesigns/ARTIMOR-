<?php

return [
    'home' => 'Home',
    'contact_us' => 'Contacteer ons',
    'visit_us_daily' => 'Bezoek ons dagelijks:',
    'connect_with_us' => 'Neem contact met ons op:',
    'dropdown_language_label' => 'Taal',
];

