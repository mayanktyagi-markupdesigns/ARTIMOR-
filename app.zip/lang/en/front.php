<?php

return [
    'home' => 'Home',
    'contact_us' => 'Contact Us',
    'visit_us_daily' => 'Visit Us Daily:',
    'connect_with_us' => 'Connect With Us:',
    'dropdown_language_label' => 'Language',
];

