<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Artimar Login</title>
    <meta name="robots" content="noindex, nofollow" />
    <link rel="shortcut icon" href="<?php echo e(asset('assets/front/img/fivicon.png')); ?>" type="image/x-icon" />

    <!-- Fonts & Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet" />

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/login.css')); ?>" />
    <style>
        body {
            position: relative;
            margin: 0;
            padding: 0;
            font-family: 'Ubuntu', sans-serif;
            background: url('<?php echo e(asset('assets/front/img/backgroud.png')); ?>') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }       
    </style>
</head>

<body>
    <div class="login-container text-center">
        <!-- Logo -->
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('assets/front/img/logo.png')); ?>" alt="Artimar Logo" />
            </a>
        </div>

        <!-- Login Form -->
        <form method="POST" action="<?php echo e(route('login.submit')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group text-start mb-3">
                <label for="email">Email ID</label><span style="color:red;">*</span>
                <input type="email" id="email" name="email" class="form-control"
                       placeholder="e.g. john@artimar.com" value="<?php echo e(old('email')); ?>" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" style="font-size: 13px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group text-start mb-2">
                <label for="password">Password</label><span style="color:red;">*</span>
                <input type="password" id="password" name="password" class="form-control"
                       placeholder="Enter Your Password"  />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" style="font-size: 13px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <a href="<?php echo e(route('forgot.password')); ?>" class="forgot-password">Forgot Password?</a>
            </div>
            <div class="text-center my-5">
                <button type="submit" class="btn btn-dark btn-primary px-4">Login</button>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>

    <!-- SweetAlert2 Popup -->
    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo e(session('success')); ?>',
                confirmButtonColor: '#3085d6',
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops!',
                text: '<?php echo e(session('error')); ?>',
                confirmButtonColor: '#d33',
            });
        <?php endif; ?>

        <?php if($errors->any() && !session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops!',
                html: `<?php echo implode('<br>', $errors->all()); ?>`,
                confirmButtonColor: '#d33',
            });
        <?php endif; ?>
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\artimar\resources\views/front/login.blade.php ENDPATH**/ ?>