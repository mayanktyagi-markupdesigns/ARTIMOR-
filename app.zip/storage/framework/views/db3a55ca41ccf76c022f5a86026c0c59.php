<div class="materials-tab-wrapper">
    <div class="d-flex align-items-center justify-content-center materials-tab-div">
        <?php if($materialCategories->isNotEmpty()): ?>
            <ul class="border-0 nav nav-tabs justify-content-center mb-5" id="materialsTab" role="tablist">
                <?php $__currentLoopData = $materialCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $tabId = \Illuminate\Support\Str::slug($categoryName ?: 'Other');
                    ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link <?php echo e($index === 0 ? 'active' : ''); ?>"
                            id="<?php echo e($tabId); ?>-tab"
                            data-bs-toggle="tab"
                            data-bs-target="#<?php echo e($tabId); ?>"
                            type="button"
                            role="tab">
                            <?php echo e($categoryName ?: 'Other'); ?>

                        </button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <div class="py-5 text-center w-100">
                <p class="mb-0">No materials available at the moment.</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if($materialCategories->isNotEmpty()): ?>
        <div class="tab-content" id="materialsTabContent">
            <?php $__currentLoopData = $materialsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $categoryMaterials): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $tabId = \Illuminate\Support\Str::slug($categoryName ?: 'Other');
                ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="<?php echo e($tabId); ?>" role="tabpanel"
                    aria-labelledby="<?php echo e($tabId); ?>-tab">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $categoryMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $productGroup = $productsByMaterial->get($material->id, collect());
                                $typeNames = $productGroup->pluck('materialType.name')->filter()->unique()->values();
                                $layoutNames = $productGroup->pluck('materialLayout.name')->filter()->unique()->values();
                                $productIds = $productGroup->pluck('id')->unique()->values()->implode(',');
                                $materialImage = $material->image
                                    ? asset('uploads/materials/' . $material->image)
                                    : asset('assets/front/img/product-circle.jpg');
                            ?>
                            <div class="col-md-4 mb-4">
                                <div class="card border-0 rounded-0 position-relative product-col material-card <?php echo e((string)($selectedMaterialId ?? '') === (string)$material->id ? 'selected' : ''); ?>"
                                    data-id="<?php echo e($material->id); ?>"
                                    data-product-ids="<?php echo e($productIds); ?>">
                                    <img src="<?php echo e($materialImage); ?>" class="card-img-top"
                                        alt="<?php echo e($material->name); ?>">
                                    <div class="card-body text-center p-0">
                                        <div class="titleoverlay">
                                            <div>
                                                <span><?php echo e($loop->iteration); ?>.</span> <?php echo e($material->name); ?>

                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 text-center py-5">
                                <p class="mb-0">No materials available in this category.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<?php /**PATH C:\xampp\htdocs\artimar\resources\views/front/partials/material-price.blade.php ENDPATH**/ ?>